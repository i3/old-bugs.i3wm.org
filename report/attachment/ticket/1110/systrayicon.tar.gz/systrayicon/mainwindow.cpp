#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QMenu>
#include <QTimer>
#include <QSystemTrayIcon>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QTimer::singleShot(0, this, SLOT(icon()));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::icon()
{
    QSystemTrayIcon *icon = new QSystemTrayIcon(this);
    icon->setContextMenu(new QMenu());
    icon->setIcon(QIcon("/path/to/some/image"));
    icon->show();
}
