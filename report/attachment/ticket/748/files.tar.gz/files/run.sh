#!/bin/bash

xinit ./.xinitrc -- /usr/bin/Xephyr :1 -screen 1366x768

